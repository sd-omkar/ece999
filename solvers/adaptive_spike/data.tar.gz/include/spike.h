/*******************************************************************************
!                              INTEL CONFIDENTIAL
!   Copyright(C) 2008 Intel Corporation. All Rights Reserved.
!   The source code contained  or  described herein and all documents related to
!   the source code ("Material") are owned by Intel Corporation or its suppliers
!   or licensors.  Title to the  Material remains with  Intel Corporation or its
!   suppliers and licensors. The Material contains trade secrets and proprietary
!   and  confidential  information of  Intel or its suppliers and licensors. The
!   Material  is  protected  by  worldwide  copyright  and trade secret laws and
!   treaty  provisions. No part of the Material may be used, copied, reproduced,
!   modified, published, uploaded, posted, transmitted, distributed or disclosed
!   in any way without Intel's prior express written permission.
!   No license  under any  patent, copyright, trade secret or other intellectual
!   property right is granted to or conferred upon you by disclosure or delivery
!   of the Materials,  either expressly, by implication, inducement, estoppel or
!   otherwise.  Any  license  under  such  intellectual property  rights must be
!   express and approved by Intel in writing.
!******************************************************************************/
#ifndef _SPIKE_C
#define _SPIKE_C
#endif

#include "spike_c_wrapper.h"


typedef struct { 
 array_dim2 VWg,redA,UL,EE1, EE2, S1, S2;
 array_dim1 IPIV,IPIV1,comm_bot,comm_top;
 array_dim3 sV,sW; 
} spike_work_c_interface; 
   
   
typedef struct {  
  char format; 
  array_dim1 saj,sbj,scj,sal,ai,sa;
  array_dim1 isaj,jsaj,isbj,jsbj,iscj,jscj,isa,jsa;
  int nbsa,nbsaj,nbsbj,nbscj;
  array_dim2 A,Aj,Bj,Cj; 
  char ASTRU,AFAC,DIAGDO;
  double vDIAGDO, sparsity;
  int kl,ku,band,sizeAj,n;
  array_dim1   sizeA; 
  int PT[64], IPARM[64]; 
  int MTYPE,MAXFCT,MNUM,PHASE,MSGLVL;
  array_dim1  PARM; 
} matrix_data_c_interface; 
   
 
typedef struct { 
  int rank; 
  int sizeAj,sizeA1,nbpart,nbprocs;
  unsigned long int file_output;        /* need to change integer to interger*8 in Fortran code */ 
  int tp,threads; 
  array_dim1 Ajmin; 
  char  RSS,DFS,RETRIE;
  int nbit_in,nbit_out,OIS,nb_boost,apblock,nbit_in0,nbit_out0;
  double eps_in,eps_out,vboost,nzero,memory,maxres;
  double tspike_prep,tspike_process,tspike_residual,tspike_preparation;
  array_dim1 res; 
  int comd,autoadapt,autoadapt_inputs,failed,timing,memfree,residual,singular,blocked,boost,invred;
  int balance; 
  int new_comm_world,nrhs,bwblock;
  spike_work_c_interface work;
  int sparse2dense;
  int BPS;
  /* !! SPIKE_Adapt information
     ! Time spent in SPIKE_Adapt */     
  double tspike_adapt;

  /* ! Error code for Spike_Adapt */ 
  int ierr_spike_adapt,error_code; 
} spike_param_c_interface; 


/*void srbwd(int *n, array_dim1 *ja, array_dim1 *ia, int *kl, int *ku);*/
void spike_default(spike_param_c_interface *pspike);
void spike_begin(spike_param_c_interface *pspike, matrix_data_c_interface *mat, matrix_data_c_interface *pre, int *info);
void spike_preprocess(spike_param_c_interface *pspike, matrix_data_c_interface *pre, int *info);
//void balance_preprocess(spike_param_c_interface *pspike, matrix_data_c_interface *pre, int *info);
void spike_process(spike_param_c_interface *pspike, matrix_data_c_interface *mat, matrix_data_c_interface *pre,array_dim2 *f, int *info);
//void balance_process(spike_param_c_interface *pspike, matrix_data_c_interface *mat, matrix_data_c_interface *pre,array_dim2 *f, int *info);
void spike_end(spike_param_c_interface *pspike, matrix_data_c_interface *mat, matrix_data_c_interface *pre, int *info);
void spike(spike_param_c_interface *pspike, matrix_data_c_interface *mat, array_dim2 *f, int *info);
void spike_solver(spike_param_c_interface *pspike, matrix_data_c_interface *pre,array_dim2 *f, int *info);

