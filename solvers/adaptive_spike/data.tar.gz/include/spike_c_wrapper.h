/*******************************************************************************
!                              INTEL CONFIDENTIAL
!   Copyright(C) 2008 Intel Corporation. All Rights Reserved.
!   The source code contained  or  described herein and all documents related to
!   the source code ("Material") are owned by Intel Corporation or its suppliers
!   or licensors.  Title to the  Material remains with  Intel Corporation or its
!   suppliers and licensors. The Material contains trade secrets and proprietary
!   and  confidential  information of  Intel or its suppliers and licensors. The
!   Material  is  protected  by  worldwide  copyright  and trade secret laws and
!   treaty  provisions. No part of the Material may be used, copied, reproduced,
!   modified, published, uploaded, posted, transmitted, distributed or disclosed
!   in any way without Intel's prior express written permission.
!   No license  under any  patent, copyright, trade secret or other intellectual
!   property right is granted to or conferred upon you by disclosure or delivery
!   of the Materials,  either expressly, by implication, inducement, estoppel or
!   otherwise.  Any  license  under  such  intellectual property  rights must be
!   express and approved by Intel in writing.
!******************************************************************************/
#define _GNU_SOURCE
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 

#define F90_WRITE_NOTATION      -2 
#define F90_LOGICAL             -1 
#define F90_CHAR                0 
#define F90_STRING              1 
#define F90_INTEGER             2 
#define F90_REAL                3 
#define F90_DOUBLE_PRECISION    4 
#define F90_INTEGER_STAR_8      5 

#define ALLOC_SUCCESS	0
#define ALLOC_FAIL	-1
 
typedef struct { 
  long int nelts; 
  long int stride; 
  long int lower_bound; 
} dimension_info;   
   
typedef struct { 
  void * base;   
  long int size;    
  void * offset; 
  long int bitsets;  
  long int ndim; 
  long int reserved; 
  dimension_info dim_info[1]; 
} array_dim1; 
 
typedef struct { 
  void * base; 
  long int size;   
  void * offset; 
  long int bitsets; 
  long int ndim; 
  long int reserved; 
  dimension_info dim_info[2]; 
} array_dim2; 
   
   
typedef struct { 
  void * base; 
  long int size; 
  void * offset;    
  long int bitsets; 
  long int ndim; 
  long int reserved; 
  dimension_info dim_info[3]; 
} array_dim3; 
 
 
typedef struct { 
  void * base;   
  long int size; 
  void * offset;    
  long int bitsets; 
  long int ndim; 
  long int reserved; 
  dimension_info dim_info[]; 
} array_all_dim; 


void spike_stop_();
void char2int_(char *s, int *value);

void spike_deallocate_all_type(array_all_dim *p);
void spike_deallocate_one_integer_(array_dim1 *p);
void spike_deallocate_two_integer_(array_dim2 *p);
void spike_deallocate_three_integer_(array_dim3 *p);
void spike_deallocate_one_double_precision_(array_dim1 *p);
void spike_deallocate_two_double_precision_(array_dim2 *p);
void spike_deallocate_three_double_precision_(array_dim3 *p);

void spike_allocate_all_type(array_all_dim *p, int * firstNo, int *secondNo, int *thirdNo, int type, int *alloc_info);
void spike_allocate_one_integer_(array_dim1 *p, int * element_No, int *alloc_info);
void spike_allocate_two_integer_(array_dim2 *p, int * rowNo, int *columNo, int *alloc_info);
void spike_allocate_three_integer_(array_dim3 *p, int * firstNo, int *secondNo, int *thirdNo, int *alloc_info);
void spike_allocate_one_double_precision_(array_dim1 *p, int * element_No, int *alloc_info);
void spike_allocate_two_double_precision_(array_dim2 *p, int * rowNo, int *columNo, int *alloc_info);
void spike_allocate_three_double_precision_(array_dim3 *p, int * firstNo, int *secondNo, int *thirdNo, int *alloc_info);

void spike_open_(unsigned long int *file_id, char *filename, char *status);
void spike_read_line_(unsigned long int *file_id, void *buffer, int *type) ;
void spike_write_(unsigned long int *file_id, void *buffer, int *type);
void spike_close_(unsigned long int *file_id);




