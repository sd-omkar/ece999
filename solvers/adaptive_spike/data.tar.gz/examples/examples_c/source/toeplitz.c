/*******************************************************************************
!                              INTEL CONFIDENTIAL
!   Copyright(C) 2008 Intel Corporation. All Rights Reserved.
!   The source code contained  or  described herein and all documents related to
!   the source code ("Material") are owned by Intel Corporation or its suppliers
!   or licensors.  Title to the  Material remains with  Intel Corporation or its
!   suppliers and licensors. The Material contains trade secrets and proprietary
!   and  confidential  information of  Intel or its suppliers and licensors. The
!   Material  is  protected  by  worldwide  copyright  and trade secret laws and
!   treaty  provisions. No part of the Material may be used, copied, reproduced,
!   modified, published, uploaded, posted, transmitted, distributed or disclosed
!   in any way without Intel's prior express written permission.
!   No license  under any  patent, copyright, trade secret or other intellectual
!   property right is granted to or conferred upon you by disclosure or delivery
!   of the Materials,  either expressly, by implication, inducement, estoppel or
!   otherwise.  Any  license  under  such  intellectual property  rights must be
!   express and approved by Intel in writing.
!******************************************************************************/
#include <mpi.h>
#include "spike.h" 
#include "help.h"

array_dim2 f;                                   /* double precision,dimension(:,:), allocatable :: f          */ 
int s;                                          /* integer :: s                                               */ 
int i, j, k;                                    /* integer :: i,j                                             */

double el_diag,el_off1l,el_off1u,el_off;        /* real(kind=kind(1.0d0)) :: el_diag,el_off1l,el_off1u,el_off */ 
int rank,nb_procs,code,nbpart,smax;             /* integer :: rank,nb_procs,code,nbpart,smax                  */ 
char  sname[100];                     /* character(len=100) :: name,sname                           */ 

int info;					/*  integer :: info					      */
spike_param_c_interface pspike;  		/* type(spike_param) :: pspike				      */
matrix_data_c_interface mat, pre; 		/* type(matrix_data) :: mat,pre				      */

int main (int argc, char *argv[]) {

        char *buff, temp_name[50]; 
        size_t len; 
        FILE *fp; 
        double temp; 
 
        MPI_Init(&argc, &argv);                                 	/* call MPI_INIT(code)  				*/ 
        code = MPI_Comm_size(MPI_COMM_WORLD, &nb_procs);        	/* call MPI_COMM_SIZE(MPI_COMM_WORLD,nb_procs,code)	*/ 
        code = MPI_Comm_rank(MPI_COMM_WORLD, &rank);            	/* call MPI_COMM_RANK(MPI_COMM_WORLD,rank,code) 	*/ 
        code = MPI_Errhandler_set(MPI_COMM_WORLD, MPI_ERRORS_RETURN);   /* MPI_Errhandler_set(MPI_COMM_WORLD, MPI_ERRORS_RETURN); */
 
   /*     strcpy(name, argv[1]);  call getarg(1,name) !! ---> read arguments line	*/

        /* 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        !!!!!!!!!! INPUT PARAMETER SPIKE 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        */ 
 
        pspike.nbprocs=nb_procs;        /* pspike%nbprocs=nb_procs     */  
        pspike.rank=rank;               /* pspike%rank=rank            */ 
         

  	spike_default(&pspike);		/* call SPIKE_DEFAULT(pspike)  */

        pspike.memfree=-1;               /*pspike%memfree=.true.*/ 
        /* 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        !!! here we read all the spike parameters from the file spike.in 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        */ 

        if (rank == 0) {                      /* if (rank==0) then   */ 
 
                fp = fopen("spike_toeplitz_c.in", "r"); /* open(10,file='spike.in',status='old')  */ 
           
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.RSS = buff[0];       /* read(10,*) pspike%RSS !! WHAT TYPE OF ALGORITHM ? E (Explicit), F (on the Fly), T (Truncated) */ 
         
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.DFS = buff[0];       /* read(10,*) pspike%DFS !! WHAT TYPE of FACTORIZATION ? L (LU), U (LU, and UL)                  */ 
         
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.OIS = atoi(buff);  /* read(10,*) pspike%OIS !! WHAT TYPE OF OUTSIDE SOLVER ? 0 (DIRECT), 1 (JACOBI), 2 (ITREFINEM), 3 (BiCGStab) */ 
         
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.eps_out = atof(buff); /* read(10,*) pspike%eps_out !!  ACCURACY BiCGstab OUTSIDE                                        */ 
           
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.nbit_out = atoi(buff); /* read(10,*) pspike%nbit_out  !!NBRE MAX of ITERATIONS OUTSIDE                                  */ 
         
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.eps_in = atof(buff);   /* read(10,*) pspike%eps_in !! ACCURACY BiCGstab INSIDE                                          */ 
           
		buff = NULL;
                getline(&buff, &len, fp);    
                pspike.nbit_in = atoi(buff);  /* read(10,*) pspike%nbit_in  !! NBRE MAX of ITERATIONS INSIDE                                   */ 
         
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.nzero = atof(buff);    /* read(10,*) pspike%nzero  !! BOOST                                                             */ 
           
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.tp = atoi(buff);       /* read(10,*) pspike%tp !! type of partitionning (o:normal,global,1:by hand sustomized)          */ 
         
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.timing = atoi(buff);   /* read(10,*) pspike%timing !!timing                                                             */ 
         
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.comd = atoi(buff);     /* read(10,*) pspike%comd   !!detail information of the simulation                               */    
         
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.file_output = strtoul(buff, NULL, 16);   
                                              /* read(10,*) pspike%file_output !!  6 on screen, for file choose /=6                            */ 
                 
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.autoadapt = atoi(buff);     /* read(10,*) pspike%autoadapt   !! to allow spike tune                                               */ 
                 
                fclose(fp);                   /* close(10)                                                                                     */ 
 
        }  /* end if */ 


        /* 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        !!!!!!!!!!!! All processors together 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        */ 
 
        /* call MPI_BCAST(pspike%RSS,1,MPI_CHARACTER,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.RSS),1,MPI_CHARACTER,0,MPI_COMM_WORLD); 
 
        /* call MPI_BCAST(pspike%DFS,1,MPI_CHARACTER,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.DFS),1,MPI_CHARACTER,0,MPI_COMM_WORLD); 
 
        /* call MPI_BCAST(pspike%OIS,1,MPI_INTEGER,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.OIS),1,MPI_INTEGER,0,MPI_COMM_WORLD); 
 
        /* call MPI_BCAST(pspike%eps_out,1,MPI_DOUBLE_PRECISION,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.eps_out),1,MPI_DOUBLE_PRECISION,0,MPI_COMM_WORLD); 
 
        /* call MPI_BCAST(pspike%nbit_out,1,MPI_INTEGER,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.nbit_out),1,MPI_INTEGER,0,MPI_COMM_WORLD); 
 
        /* call MPI_BCAST(pspike%eps_in,1,MPI_DOUBLE_PRECISION,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.eps_in),1,MPI_DOUBLE_PRECISION,0,MPI_COMM_WORLD); 
 
        /*call MPI_BCAST(pspike%nbit_in,1,MPI_INTEGER,0,MPI_COMM_WORLD,code)*/ 
        MPI_Bcast(&(pspike.nbit_in),1,MPI_INTEGER,0,MPI_COMM_WORLD); 
 
 
        /* call MPI_BCAST(pspike%nzero,1,MPI_DOUBLE_PRECISION,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.nzero),1,MPI_DOUBLE_PRECISION,0,MPI_COMM_WORLD); 
 
        /* call MPI_BCAST(pspike%tp,1,MPI_INTEGER,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.tp),1,MPI_INTEGER,0,MPI_COMM_WORLD); 
 
        /* call MPI_BCAST(pspike%timing,1,MPI_LOGICAL,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.timing),1,MPI_LOGICAL,0,MPI_COMM_WORLD); 
 
        /* call MPI_BCAST(pspike%comd,1,MPI_LOGICAL,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.comd),1,MPI_LOGICAL,0,MPI_COMM_WORLD); 

        /* call MPI_BCAST(pspike%file_output,1,MPI_INTEGER,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.file_output),1,MPI_UNSIGNED_LONG,0,MPI_COMM_WORLD); 
 
        /* call MPI_BCAST(pspike%autoadapt,1,MPI_LOGICAL,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.autoadapt),1,MPI_LOGICAL,0,MPI_COMM_WORLD); 


        /* 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        !!!!!!!!!! INPUT PARAMETER MATRIX 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        !!!!!! read matrix parameter for banded in a file 
        */ 
 
                mat.format='D';                 /* mat%format='D'                                                 */ 
                mat.ASTRU='G';                  /* mat%ASTRU='G'                                                  */ 

        fp = fopen("matrix_toeplitz_c.in", "r");  

 
		buff = NULL;
                getline(&buff, &len, fp); 
                mat.n = atoi(buff);             /* read(10,*) mat%n  !! size of the matrix                        */ 
 
		buff = NULL;
                getline(&buff, &len, fp); 
                mat.kl = atoi(buff);            /* read(10,*) mat%kl !! Lower band                                */ 
 
		buff = NULL;
                getline(&buff, &len, fp); 
                mat.ku = atoi(buff);            /* read(10,*) mat%ku !! Upper band                                */     
 
		buff = NULL;
                getline(&buff, &len, fp); 
                el_diag = atof(buff);           /* read(10,*) el_diag !! diagonal element                         */ 
 
		buff = NULL;
                getline(&buff, &len, fp);  
                el_off1l = atof(buff);          /* read(10,*) el_off1l !! first lower off diagonal element        */ 
 
		buff = NULL;
                getline(&buff, &len, fp); 
                el_off1u = atof(buff);          /* read(10,*) el_off1u !! first upper off diagonal element        */ 
 
		buff = NULL;
                getline(&buff, &len, fp); 
                el_off = atof(buff);            /* read(10,*) el_off  !! OTHERS off diagonal element              */ 
 
		buff = NULL;
                getline(&buff, &len, fp); 
                s = atoi(buff);                 /* read(10,*) s !! number of RHS (THE value of the RHS are generated by the code) */ 

		buff = NULL;
                getline(&buff, &len, fp); 
                mat.DIAGDO = buff[0];           /* read(10,*) mat%DIAGDO !! IS IT DIAGONALLY DOMINANT ? Y (Yes), N (No)          */ 

                fclose(fp);                     /*  close(10)                     */ 

                /* !!!!!! TYPE OF ORIGINAL STORAGE for SPIKE                      */ 
                switch (pspike.tp) {            /* select case(pspike%tp)         */ 
                        case 0:                 /*  case(0) !!!!!! global storage */ 
                           if (rank == 0) {     /* if (rank==0) then              */ 
 
                                /* allocate(mat%A(1:mat%kl+mat%ku+1,mat%n))       */ 
                                alloc2D_D(&(mat.A), mat.kl+mat.ku+1, mat.n); 
 
                                /* mat%A=el_off */ 
                                setAll_D(&(mat.A), &(el_off)); 
 
                                /* mat%A(mat%ku,:)=el_off1u */ 
                                setRow_D(&(mat.A), mat.ku, el_off1u); 
 
                                /* mat%A(mat%ku+1,:)=el_diag */ 
                                setRow_D(&(mat.A), mat.ku+1, el_diag); 
 
                                /* mat%A(mat%ku+2,:)=el_off1l */ 
                                setRow_D(&(mat.A), mat.ku+2, el_off1l); 
 
                                /* allocate(f(1:mat%n,1:s)) */ 
                                alloc2D_D(&f, mat.n, s); 
 
                                /* f=1.0d0 */ 
                                temp = 1.0e0; 
                                setAll_D(&f, &temp); 
 
                            }     /*     end if      */ 

                            break; 

                        case 1:   /* case (1) !!!!! Local storage  */ 
                                nbpart=pspike.nbprocs;        
 
                            alloc1D_I(&(mat.sizeA), nbpart);    /* allocate(mat%sizeA(1:nbpart))        */ 
                            smax=mat.n/nbpart;                  /* smax=mat%n/nbpart                    */ 
                 
                            if (mat.n > smax*nbpart) smax=smax+1;                        
                                                                        /* if (mat%n>smax*nbpart) smax=smax+1 !! here last partition smaller than all others */ 
 
                            /* !! Seek the size of each partition  */ 
			    setRange_I(&(mat.sizeA), smax, 1, nbpart-1);			/* mat%sizeA(1:nbpart-1)=smax;          */
			    setElem1D_I(&(mat.sizeA), nbpart, mat.n-smax*(nbpart-1));		/* mat%sizeA(nbpart)=mat%n-smax*(nbpart-1)      */ 
 
 
                                j = *((int *)(mat.sizeA.base) + rank); 
				alloc2D_D(&(mat.A), mat.kl+mat.ku+1, j);        /* allocate(mat%A(1:mat%kl+mat%ku+1,mat%sizeA(rank+1)))        */
 
                                /* mat%A=el_off */ 
                                setAll_D(&(mat.A), &el_off); 
 
                                /* mat%A(mat%ku,:)=el_off1u */ 
                                setRow_D(&(mat.A), mat.ku, el_off1u); 
 
                                /* mat%A(mat%ku+1,:)=el_diag */ 
                                setRow_D(&(mat.A), mat.ku+1, el_diag); 
 
                                /* mat%A(mat%ku+2,:)=el_off1l */ 
                                setRow_D(&(mat.A), mat.ku+2, el_off1l); 
 
                         
                            /* !! Right Hand Side --- arbitrary local */ 
				i = getElem1D_I(&(mat.sizeA), rank+1);
                                alloc2D_D(&f, i, s);       /* allocate(f(1:mat%sizeA(rank+1),1:s)) */ 
                                 
                                temp = 1.0e0; 
                                setAll_D(&f, &temp);      /*  f=1.0d0                             */ 
     
                } /*  end select */ 
         


	/*
	!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	!!!!!!!!!!!!!!!!!!!! SPIKE ENVIRONMENT !!!!!!!!!
	!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        */  
 /*     spike(&pspike,&mat,&f,&info)  !! can be chosen in place of the following lines---*/


	spike_begin(&pspike,&mat,&pre, &info);          

        spike_preprocess(&pspike,&pre, &info);

        spike_process(&pspike,&mat,&pre,&f, &info);

        spike_end(&pspike,&mat,&pre, &info);           



	MPI_Finalize();		/* 101 call MPI_FINALIZE(code) */

	return 0;
}

