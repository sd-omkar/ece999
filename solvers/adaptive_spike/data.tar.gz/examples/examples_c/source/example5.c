/*******************************************************************************
!                              INTEL CONFIDENTIAL
!   Copyright(C) 2008 Intel Corporation. All Rights Reserved.
!   The source code contained  or  described herein and all documents related to
!   the source code ("Material") are owned by Intel Corporation or its suppliers
!   or licensors.  Title to the  Material remains with  Intel Corporation or its
!   suppliers and licensors. The Material contains trade secrets and proprietary
!   and  confidential  information of  Intel or its suppliers and licensors. The
!   Material  is  protected  by  worldwide  copyright  and trade secret laws and
!   treaty  provisions. No part of the Material may be used, copied, reproduced,
!   modified, published, uploaded, posted, transmitted, distributed or disclosed
!   in any way without Intel's prior express written permission.
!   No license  under any  patent, copyright, trade secret or other intellectual
!   property right is granted to or conferred upon you by disclosure or delivery
!   of the Materials,  either expressly, by implication, inducement, estoppel or
!   otherwise.  Any  license  under  such  intellectual property  rights must be
!   express and approved by Intel in writing.
!******************************************************************************/
#include <mpi.h> 
#include "spike.h" 
#include "help.h" 
 
int rank, code, nb_procs,i,j,k;                 /* integer :: rank,code,nb_procs,i                      */ 
array_dim2 f;                                   /* double precision,dimension(:,:), allocatable :: f    */ 

int info;					/* integer :: info					*/
spike_param_c_interface pspike;                 /* type(spike_param) :: pspike                          */ 
matrix_data_c_interface mat;               	/* type(matrix_data) :: mat                         	*/

int main (int argc, char **argv) {
 
        double temp; 
        double temp_sa[] = {6,-1,6,-1,-1,6,-1,-1,6,-1,-1,6,-1,-1,6,-1,-1,6,-1,6}; 
        int temp_jsa[] = {1,3,2,4,1,3,5,2,4,6,3,5,7,4,6,8,5,7,6,8}; 
        int temp_isa[] = {1,3,5,8,11,14,17,19,21}; 

        code = MPI_Init(&argc, &argv);                                 	/* call MPI_INIT(code)  */ 
        code = MPI_Comm_size(MPI_COMM_WORLD, &nb_procs);        	/* call MPI_COMM_SIZE(MPI_COMM_WORLD,nb_procs,code)*/ 
        code = MPI_Comm_rank(MPI_COMM_WORLD, &rank);            	/* call MPI_COMM_RANK(MPI_COMM_WORLD,rank,code) */
        code = MPI_Errhandler_set(MPI_COMM_WORLD, MPI_ERRORS_RETURN);   /* MPI_Errhandler_set(MPI_COMM_WORLD, MPI_ERRORS_RETURN); */

        /* 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        !!!!!!!!!! INPUT PARAMETER SPIKE 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        */ 
 
        pspike.nbprocs=nb_procs;        /* pspike%nbprocs=nb_procs      */  
        pspike.rank=rank;               /* pspike%rank=rank             */  

        spike_default(&pspike);  /* call SPIKE_DEFAULT(pspike)  */ 
 
        /* 
        !! changes from default 
        */ 
        pspike.autoadapt=0;             /* pspike%autoadapt=.false.   */ 
        pspike.RSS='F';
        pspike.DFS='L'; 
        /* 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        !!!!!!!!!! INPUT PARAMETER MATRIX and RHS 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        */ 

        mat.format='S';         /* mat%format='S' */ 
        mat.ASTRU='G';          /* mat%ASTRU='G'  */ 
        mat.DIAGDO='Y';         /* mat%DIAGDO='Y' */ 
      
        mat.n=8;                /* mat%n=8      */ 

        if(rank == 0) {                 /* if (rank==0) then   */
                mat.nbsa=20;            /* mat%nbsa=20 !! number of non-zero elements in CSR format */

        	alloc1D_D(&(mat.sa), mat.nbsa);    /* allocate(mat%sa(1:mat%nbsa))  ! array for values */
 
        	alloc1D_I(&(mat.jsa), mat.nbsa);    /* allocate(mat%jsa(1:mat%nbsa)) ! array for column indexes */
 
        	alloc1D_I(&(mat.isa), mat.n+1);    /* allocate(mat%isa(1:mat%n+1))  ! array for row CSR indexes */
    
        	for (i = 0; i < mat.nbsa; i++) setElem1D_D(&(mat.sa), i+1, temp_sa[i]);     /* mat%sa=(/6,-1,6,-1,-1,6,-1,-1,6,-1,-1,6,-1,-1,6,-1,-1,6,-1,6/) */ 
 
        	for (i = 0; i < mat.nbsa; i++) setElem1D_I(&(mat.jsa), i+1, temp_jsa[i]);       /* mat%jsa=(/1,3,2,4,1,3,5,2,4,6,3,5,7,4,6,8,5,7,6,8/)  */ 
 
        	for (i = 0; i < mat.n+1; i++)  setElem1D_I(&(mat.isa), i+1, temp_isa[i]);        /* mat%isa=(/1,3,5,8,11,14,17,19,21/)   */

        	/* !! RHS       */   
        	alloc2D_D(&f, mat.n, 1);       /* allocate(f(1:mat%n,1:1))     */ 
 
        	temp = 1.0e0; 
        	setAll_D(&f, &temp);              /* f=1.0d0                      */  
 
        }  /* end if */ 

 
        /* 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        !!!!!!!!!! CALLING SPIKE !!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        */ 
 
        spike(&pspike, &mat, &f, &info);                /* call SPIKE(pspike,mat,f,info)     */


	if (info>=0)				/* if (info>=0) then 		*/
        if (rank==0) {                          /* if (rank==0) then            */ 
                printf(" Global solution\n");   /* print *,'Global solution'    */ 
 
                for(i=0; i < mat.n; i++)                                        /* do i=1,mat%n         */ 
                        printf("%d\t%.15e\n", i+1, getElem2D_D(&f, i+1, 1));     /* print *,i,f(i,1)     */ 
 
        } /* end if */ 

        MPI_Finalize();         /* call MPI_FINALIZE(code)  */ 
 
        return 0; 
} 




