/*******************************************************************************
!                              INTEL CONFIDENTIAL
!   Copyright(C) 2008 Intel Corporation. All Rights Reserved.
!   The source code contained  or  described herein and all documents related to
!   the source code ("Material") are owned by Intel Corporation or its suppliers
!   or licensors.  Title to the  Material remains with  Intel Corporation or its
!   suppliers and licensors. The Material contains trade secrets and proprietary
!   and  confidential  information of  Intel or its suppliers and licensors. The
!   Material  is  protected  by  worldwide  copyright  and trade secret laws and
!   treaty  provisions. No part of the Material may be used, copied, reproduced,
!   modified, published, uploaded, posted, transmitted, distributed or disclosed
!   in any way without Intel's prior express written permission.
!   No license  under any  patent, copyright, trade secret or other intellectual
!   property right is granted to or conferred upon you by disclosure or delivery
!   of the Materials,  either expressly, by implication, inducement, estoppel or
!   otherwise.  Any  license  under  such  intellectual property  rights must be
!   express and approved by Intel in writing.
!******************************************************************************/
#include "help.h"

void errMessage() {

	printf("Memory allocation failure!");
	exit(0);
}


void setAll(void *p, void *value, int type) {

	int i, length;
	void *space;
	dimension_info *dim;
	array_all_dim *ptr = (array_all_dim *) p;

	space = ptr->base;

	i = (int) ptr->ndim;

	dim = &(ptr->dim_info[i-1]);
	length = (int) (dim->stride * dim->nelts / ptr->size);

	for (i = 0; i < length; i++) {
		if (type == F90_INTEGER)
			*(int *)((unsigned long int)space + i*ptr->size) = *(int *)value;
		else /* type == F90_DOUBLE_PRECISION */
			*(double *)((unsigned long int)space + i*ptr->size) = *(double *)value; 
	}
}

void setAll_D(void *p, void *value) {

	setAll(p, value, F90_DOUBLE_PRECISION);

}

void setAll_I(void *p, void *value) {

	setAll(p, value, F90_INTEGER);

}

void setRange(array_dim1 *p, void *value, int start, int end, int type) { 
 
        int i; 
        void *space = p->base; 
 
        for (i = start-1; i < end; i++) { 
                if (type == F90_INTEGER) 
                        *(int *)((unsigned long int)space + i*p->size) = *(int *)value; 
                else /* type == F90_DOUBLE_PRECISION */ 
                        *(double *)((unsigned long int)space + i*p->size) = *(double *)value;  
        } 
} 

void setRange_D(array_dim1 *p, double value, int start, int end) {

	setRange(p, &value, start, end, F90_DOUBLE_PRECISION);

}


void setRange_I(array_dim1 *p, int value, int start, int end) {

	setRange(p, &value, start, end, F90_INTEGER);

}


  
void setRow(array_dim2 *p, int row, void *value, int type) { 

	int size1, size2, k;
	void *space;

	space = p->base;

	size1 = p->dim_info[0].nelts;
	size2 = p->dim_info[1].nelts;
	
	for (k = 0; k < size2; k++) {
		if (type == F90_INTEGER) 
			*(int *)((unsigned long int)space + (row-1 + k*size1)*p->size) = *(int *)value;
		else /* type = F90_DOUBLE_PRECISION */
			*(double *)((unsigned long int)space + (row-1 + k*size1)*p->size) = *(double *)value;
	}
}


void setRow_D(array_dim2 *p, int row, double value) {

	setRow(p, row, &value, F90_DOUBLE_PRECISION);

}  

void setRow_I(array_dim2 *p, int row, int value) {

	setRow(p, row, &value, F90_INTEGER);

}


void setElem1D_D(array_dim1 *p, int element_No, double value) {

        *((double *)(p->base) + element_No-1) = value; 
  
}

void setElem1D_I(array_dim1 *p, int element_No, int value) { 
 
        *((int *)(p->base) + element_No-1) = value; 
 
} 

void setElem2D(array_dim2 *p, int row, int column, void *value, int type) {

	int size1;
	void *space;

	space = p->base;
	size1 = p->dim_info[0].nelts;

	if (type == F90_INTEGER)
		*(int *)((unsigned long int)space + (row-1 + (column-1)*size1)*p->size) = *(int *)value;
	else /* type == F90_DOUBLE_PRECISION */
		*(double *)((unsigned long int)space + (row-1 + (column-1)*size1)*p->size) = *(double *)value;
}


void setElem2D_D(array_dim2 *p, int row, int column, double value) {

	setElem2D(p, row, column, &value, F90_DOUBLE_PRECISION);

}

void setElem2D_I(array_dim2 *p, int row, int column, int value) {

	setElem2D(p, row, column, &value, F90_INTEGER);

}

double getElem1D_D(array_dim1 *p, int element_No) {

	double result = *((double *)(p->base) + element_No - 1);

	return result;
}


int getElem1D_I(array_dim1 *p, int element_No) {

        int result = *((int *)(p->base) + element_No - 1); 
 
        return result;
} 
 
double getElem2D_D(array_dim2 *p, int row, int column) {

        int size1; 
        void *space; 
	double result;
 
        space = p->base; 
        size1 = p->dim_info[0].nelts; 
 
        result =  *((double *)space + row-1 + (column-1)*size1); 

	return result;
}   

int getElem2D_I(array_dim2 *p, int row, int column) {

        int size1, result;  
        void *space;  
  
        space = p->base;  
        size1 = p->dim_info[0].nelts;  
  
        result =  *((int *)space + row-1 + (column-1)*size1);  
 
        return result;
}


void dealloc(void *p) {

	array_all_dim *p1 = (array_all_dim *) p;
	spike_deallocate_all_type(p1);

}


void alloc1D_I(array_dim1 *p, int element_No) {

	int alloc_info = 0;

	spike_allocate_one_integer_(p, &element_No, &alloc_info);

	if (alloc_info == -1) errMessage();
	
}

void alloc2D_I(array_dim2 *p, int rowNo, int columNo) {

	int alloc_info = 0;

	spike_allocate_two_integer_(p, &rowNo, &columNo, &alloc_info); 

	if (alloc_info == -1) errMessage();
}


void alloc3D_I(array_dim3 *p, int firstNo, int secondNo, int thirdNo) {

	int alloc_info = 0;
	
	spike_allocate_three_integer_(p, &firstNo, &secondNo, &thirdNo, &alloc_info); 

	if (alloc_info == -1) errMessage();
}

void alloc1D_D(array_dim1 *p, int element_No) {

	int alloc_info = 0;	

	spike_allocate_one_double_precision_(p, &element_No, &alloc_info); 

	if (alloc_info == -1) errMessage();
}

void alloc2D_D(array_dim2 *p, int rowNo, int columNo) {

	int alloc_info = 0;

	spike_allocate_two_double_precision_(p, &rowNo, &columNo, &alloc_info);

	if (alloc_info == -1) errMessage();
}

void alloc3D_D(array_dim3 *p, int firstNo, int secondNo, int thirdNo) {

	int alloc_info = 0;

	spike_allocate_three_double_precision_(p, &firstNo, &secondNo, &thirdNo, &alloc_info);

	if (alloc_info == -1) errMessage();
}
