/*******************************************************************************
!                              INTEL CONFIDENTIAL
!   Copyright(C) 2008 Intel Corporation. All Rights Reserved.
!   The source code contained  or  described herein and all documents related to
!   the source code ("Material") are owned by Intel Corporation or its suppliers
!   or licensors.  Title to the  Material remains with  Intel Corporation or its
!   suppliers and licensors. The Material contains trade secrets and proprietary
!   and  confidential  information of  Intel or its suppliers and licensors. The
!   Material  is  protected  by  worldwide  copyright  and trade secret laws and
!   treaty  provisions. No part of the Material may be used, copied, reproduced,
!   modified, published, uploaded, posted, transmitted, distributed or disclosed
!   in any way without Intel's prior express written permission.
!   No license  under any  patent, copyright, trade secret or other intellectual
!   property right is granted to or conferred upon you by disclosure or delivery
!   of the Materials,  either expressly, by implication, inducement, estoppel or
!   otherwise.  Any  license  under  such  intellectual property  rights must be
!   express and approved by Intel in writing.
!******************************************************************************/
#include <mpi.h> 
#include "spike.h" 
#include "help.h" 
 
int rank, code, nb_procs, i,j,k;              /*  integer :: rank,code,nb_procs,i                      */ 
array_dim2 f;                                   /* double precision,dimension(:,:), allocatable :: f     */ 

int info;                                    /*  integer :: info                                      */ 
spike_param_c_interface pspike;                 /* type(spike_param) :: pspike                           */ 
matrix_data_c_interface mat;                    /* type(matrix_data) :: mat                              */ 

int main (int argc, char **argv) { 
 
        void *space; 
        double temp; 
         
        code = MPI_Init(&argc, &argv);                          /* call MPI_INIT(code)  */ 
        code = MPI_Comm_size(MPI_COMM_WORLD, &nb_procs);        /* call MPI_COMM_SIZE(MPI_COMM_WORLD,nb_procs,code)*/ 
        code = MPI_Comm_rank(MPI_COMM_WORLD, &rank);            /* call MPI_COMM_RANK(MPI_COMM_WORLD,rank,code) */ 
        code = MPI_Errhandler_set(MPI_COMM_WORLD, MPI_ERRORS_RETURN);   /* MPI_Errhandler_set(MPI_COMM_WORLD, MPI_ERRORS_RETURN); */
 
        /* 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        !!!!!!!!!! INPUT PARAMETER SPIKE 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        */ 
 
        pspike.nbprocs=nb_procs;        /* pspike%nbprocs=nb_procs      */  
        pspike.rank=rank;               /* pspike%rank=rank             */  

        spike_default(&pspike);  /* call SPIKE_DEFAULT(pspike)  */
 
        /* 
        !! changes from default 
        */ 
 
        pspike.tp = 1;                  /* pspike%tp=1 !! customized local partitioning of type 1         */ 
        pspike.autoadapt=0;             /* pspike%autoadapt=.false.  */ 

        /* 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        !!!!!!!!!! INPUT PARAMETER MATRIX and RHS 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        */ 
        mat.format='D';         /* mat%format='D' !! dense banded format */
        mat.ASTRU='G';          /* mat%ASTRU='G'  */
        mat.DIAGDO='Y';         /* mat%DIAGDO='Y' */

        /* !global data */ 
        mat.n=8;                /* mat%n=8      */
        mat.kl=2;               /* mat%kl=2     */  
        mat.ku=2;               /* mat%ku=2     */

        alloc1D_I(&(mat.sizeA), 2);  /* allocate(mat%sizeA(1:2)) !! only 2 partitions are considered */ 
 
        space = mat.sizeA.base; 
        setElem1D_I(&(mat.sizeA), 1, 4);                /* mat%sizeA(1)= 4 */ 
        setElem1D_I(&(mat.sizeA), 2, 4);         	/* mat%sizeA(2)= 4 */ 

        /* !local data for partition number rank+1 */ 
        j = getElem1D_I(&(mat.sizeA), rank+1);  
        alloc2D_D(&(mat.A), mat.kl+mat.ku+1, j);        /* allocate(mat%A(1:mat%kl+mat%ku+1,mat%sizeA(rank+1)))*/ 
 
        temp = 0.0e0; 
        setAll_D(&(mat.A), &temp);        
 
        temp = 6.0e0; 
        setRow_D(&(mat.A), mat.ku+1, temp);     /* mat%A(mat%ku+1,:)=6.0d0     */ 
 
        temp = -1.0e0; 
        setRow_D(&(mat.A), mat.ku-1, temp);     /* mat%A(mat%ku-1,:)=-1.0d0    */ 
 
        setRow_D(&(mat.A), mat.ku, temp);       /* mat%A(mat%ku,:)=-1.0d0      */ 
 
        setRow_D(&(mat.A), mat.ku+2, temp);     /* mat%A(mat%ku+2,:)=-1.0d0      */ 
 
        setRow_D(&(mat.A), mat.ku+3, temp);     /* mat%A(mat%ku+3,:)=-1.0d0      */


        /* !! RHS (local)       */  
	i = getElem1D_I(&(mat.sizeA), rank+1);
        alloc2D_D(&f, i, 1);       /* allocate(f(1:mat%sizeA(rank+1),1:1)) */ 
 
        temp = 1.0e0; 
        setAll_D(&f, &temp);      /* f=1.0d0 */


        /* 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        !!!!!!!!!! CALLING SPIKE !!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        */ 
 
         spike(&pspike,&mat,&f,&info);         /* call SPIKE(pspike,mat,f, info) */ 

 
	if (info>=0) {	/* if (info>=0) then */
		/* !!!!!! Local Solution */
		printf("Local solution for partition\t%d\n", rank+1);           /* print *,'Local solution for partition',rank+1 */
        	for (k = 0; k < i; k++)                                         /* do i=1,mat%sizeA(rank+1) */ 
                	printf("%d\t%.15e\n", k+1, getElem2D_D(&f, k+1, 1));     /* print *,i,f(i,1)     */
	}

        MPI_Finalize();         /* call MPI_FINALIZE(code)  */ 
 
        return 0; 
} 




