/*******************************************************************************
!                              INTEL CONFIDENTIAL
!   Copyright(C) 2008 Intel Corporation. All Rights Reserved.
!   The source code contained  or  described herein and all documents related to
!   the source code ("Material") are owned by Intel Corporation or its suppliers
!   or licensors.  Title to the  Material remains with  Intel Corporation or its
!   suppliers and licensors. The Material contains trade secrets and proprietary
!   and  confidential  information of  Intel or its suppliers and licensors. The
!   Material  is  protected  by  worldwide  copyright  and trade secret laws and
!   treaty  provisions. No part of the Material may be used, copied, reproduced,
!   modified, published, uploaded, posted, transmitted, distributed or disclosed
!   in any way without Intel's prior express written permission.
!   No license  under any  patent, copyright, trade secret or other intellectual
!   property right is granted to or conferred upon you by disclosure or delivery
!   of the Materials,  either expressly, by implication, inducement, estoppel or
!   otherwise.  Any  license  under  such  intellectual property  rights must be
!   express and approved by Intel in writing.
!******************************************************************************/
#include <mpi.h>
#include "spike.h" 
#include "help.h"

array_dim2 f;                                   /* double precision,dimension(:,:), allocatable :: f          */ 
int s;                                          /* integer :: s                                               */ 
int i, j, k;                                    /* integer :: i,j                                             */
int sparse2dbanded;

int rank,nb_procs,code;             /* integer :: rank,nb_procs,code,nbpart,smax                  */ 
char sname[100];                     /* character(len=100) :: name,sname                           */ 

int info;					/*  integer :: info(4)					      */
spike_param_c_interface pspike;  		/* type(spike_param) :: pspike				      */
matrix_data_c_interface mat, pre; 		/* type(matrix_data) :: mat,pre				      */

int main (int argc, char *argv[]) {

        char *buff, temp_name[50]; 
        size_t len; 
        FILE *fp; 
        double temp;
        int tempi; 
 
        MPI_Init(&argc, &argv);                                 	/* call MPI_INIT(code)  				*/ 
        code = MPI_Comm_size(MPI_COMM_WORLD, &nb_procs);        	/* call MPI_COMM_SIZE(MPI_COMM_WORLD,nb_procs,code)	*/ 
        code = MPI_Comm_rank(MPI_COMM_WORLD, &rank);            	/* call MPI_COMM_RANK(MPI_COMM_WORLD,rank,code) 	*/ 
        code = MPI_Errhandler_set(MPI_COMM_WORLD, MPI_ERRORS_RETURN);   /* MPI_Errhandler_set(MPI_COMM_WORLD, MPI_ERRORS_RETURN); */
 
/*        strcpy(name, argv[1]); 	*/

        /* 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        !!!!!!!!!! INPUT PARAMETER SPIKE 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        */ 
 
        pspike.nbprocs=nb_procs;        /* pspike%nbprocs=nb_procs     */  
        pspike.rank=rank;               /* pspike%rank=rank            */ 
         

  	spike_default(&pspike);		/* call SPIKE_DEFAULT(pspike)  */

        pspike.memfree=-1;               /* pspike%memfree=.true. */
        /* 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        !!! here we read all the spike parameters from the file spike.in 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        */ 

        if (rank == 0) {                      /* if (rank==0) then   */ 
 
                fp = fopen("spike_sparse_c.in", "r"); /* open(10,file='spike.in',status='old')  */ 
           
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.RSS = buff[0];       /* read(10,*) pspike%RSS !! WHAT TYPE OF ALGORITHM ? E (Explicit), F (on the Fly), T (Truncated) */ 
         
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.DFS = buff[0];       /* read(10,*) pspike%DFS !! WHAT TYPE of FACTORIZATION ? L (LU), U (LU, and UL)                  */ 
         
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.OIS = atoi(buff);  /* read(10,*) pspike%OIS !! WHAT TYPE OF OUTSIDE SOLVER ? 0 (DIRECT), 1 (JACOBI), 2 (ITREFINEM), 3 (BiCGStab) */ 
         
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.eps_out = atof(buff); /* read(10,*) pspike%eps_out !!  ACCURACY BiCGstab OUTSIDE                                        */ 
           
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.nbit_out = atoi(buff); /* read(10,*) pspike%nbit_out  !!NBRE MAX of ITERATIONS OUTSIDE                                  */ 
         
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.eps_in = atof(buff);   /* read(10,*) pspike%eps_in !! ACCURACY BiCGstab INSIDE                                          */ 
           
		buff = NULL;
                getline(&buff, &len, fp);    
                pspike.nbit_in = atoi(buff);  /* read(10,*) pspike%nbit_in  !! NBRE MAX of ITERATIONS INSIDE                                   */ 
         
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.nzero = atof(buff);    /* read(10,*) pspike%nzero  !! BOOST                                                             */ 
           
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.tp = atoi(buff);       /* read(10,*) pspike%tp !! type of partitionning (o:normal,global,1:by hand sustomized)          */ 
         
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.timing = atoi(buff);   /* read(10,*) pspike%timing !!timing                                                             */ 
         
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.comd = atoi(buff);     /* read(10,*) pspike%comd   !!detail information of the simulation                               */    
         
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.file_output = strtoul(buff, NULL, 16);   
                                              /* read(10,*) pspike%file_output !!  6 on screen, for file choose /=6                            */ 
                 
		buff = NULL;
                getline(&buff, &len, fp); 
                pspike.autoadapt = atoi(buff);     /* read(10,*) pspike%autoadapt   !! to allow spike tune                                               */ 
                 
                fclose(fp);                   /* close(10)                                                                                     */ 
 
        }  /* end if */ 


        /* 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        !!!!!!!!!!!! All processors together 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        */ 
 
        /* call MPI_BCAST(pspike%RSS,1,MPI_CHARACTER,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.RSS),1,MPI_CHARACTER,0,MPI_COMM_WORLD); 
 
        /* call MPI_BCAST(pspike%DFS,1,MPI_CHARACTER,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.DFS),1,MPI_CHARACTER,0,MPI_COMM_WORLD); 
 
        /* call MPI_BCAST(pspike%OIS,1,MPI_INTEGER,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.OIS),1,MPI_INTEGER,0,MPI_COMM_WORLD); 
 
        /* call MPI_BCAST(pspike%eps_out,1,MPI_DOUBLE_PRECISION,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.eps_out),1,MPI_DOUBLE_PRECISION,0,MPI_COMM_WORLD); 
 
        /* call MPI_BCAST(pspike%nbit_out,1,MPI_INTEGER,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.nbit_out),1,MPI_INTEGER,0,MPI_COMM_WORLD); 
 
        /* call MPI_BCAST(pspike%eps_in,1,MPI_DOUBLE_PRECISION,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.eps_in),1,MPI_DOUBLE_PRECISION,0,MPI_COMM_WORLD); 
 
        /*call MPI_BCAST(pspike%nbit_in,1,MPI_INTEGER,0,MPI_COMM_WORLD,code)*/ 
        MPI_Bcast(&(pspike.nbit_in),1,MPI_INTEGER,0,MPI_COMM_WORLD); 
 
        /* call MPI_BCAST(pspike%nzero,1,MPI_DOUBLE_PRECISION,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.nzero),1,MPI_DOUBLE_PRECISION,0,MPI_COMM_WORLD); 
 
        /* call MPI_BCAST(pspike%tp,1,MPI_INTEGER,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.tp),1,MPI_INTEGER,0,MPI_COMM_WORLD); 
 
        /* call MPI_BCAST(pspike%timing,1,MPI_LOGICAL,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.timing),1,MPI_LOGICAL,0,MPI_COMM_WORLD); 
 
        /* call MPI_BCAST(pspike%comd,1,MPI_LOGICAL,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.comd),1,MPI_LOGICAL,0,MPI_COMM_WORLD); 

        /* call MPI_BCAST(pspike%file_output,1,MPI_INTEGER,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.file_output),1,MPI_UNSIGNED_LONG,0,MPI_COMM_WORLD); 
 
        /* call MPI_BCAST(pspike%autoadapt,1,MPI_LOGICAL,0,MPI_COMM_WORLD,code) */ 
        MPI_Bcast(&(pspike.autoadapt),1,MPI_LOGICAL,0,MPI_COMM_WORLD); 


        /* 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        !!!!!!!!!! INPUT PARAMETER MATRIX 
        !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! 
        !!!!!! read matrix parameter for csr in a file 
        */ 


/*        if (pspike.tp/=0) {
        printf("tp/=0 not supported by this driver:\n");
	MPI_Finalize();		
	return 0;
	}
  */              

                        /* !!! ONLY GLOBAL CONSIDERED HERE */ 
                        if (rank == 0) { /* if (rank==0) then */ 

                fp = fopen("matrix_sparse_c.in", "r"); /* open(10,file='spike.in',status='old')  */
				buff = NULL;
                                getline(&buff, &len, fp); 
                                for (i = 0; i < 500; i++) {     /* trim(name) */ 
                                        if (buff[i] == ' ' || buff[i] == '!' || buff[i] == '\t') { 
                                                buff[i] = 0;     
                                                break; 
                                        } 
                                } 
                                strcpy(sname, buff);            /* read(10,*) sname  !! generic name for csr format */ 
 
				buff = NULL;
                                getline(&buff, &len, fp); 
                                mat.DIAGDO = buff[0];           /* read(10,*) mat%DIAGDO !! IS IT DIAGONALLY DOMINANT ? Y (Yes), N (No) */ 

		buff = NULL;
                getline(&buff, &len, fp); 
                sparse2dbanded = atoi(buff);      
                fclose(fp);                     /* close(10) */

                                /* !!! READ the file IN CSR format!!!! */ 
                                sprintf(temp_name, "%s.isa", sname);
  
                              fp = fopen(temp_name, "r");     /* open(10,file=trim(sname)//'.isa',status='old') */ 
 
		buff = NULL;
                getline(&buff, &len, fp); 
                mat.n = atoi(buff); 
                                alloc1D_I(&(mat.isa), mat.n+1);     /* allocate(mat%isa(1:mat%n+1)) */                               
 
                                for (k = 0; k < mat.n+1; k++){                  /* do i=1,mat%n+1               */ 
					buff = NULL;
                                        getline(&buff, &len, fp); 
					setElem1D_I(&(mat.isa), k+1, atoi(buff));	/* read(10,*) mat%isa(i)        */
                                }                                               /* end do                       */  
                                fclose(fp);                                     /* close(10)                    */ 


                                sprintf(temp_name, "%s.jsa", sname); 
                                fp = fopen(temp_name, "r");                     /* open(10,file=trim(sname)//'.jsa',status='old') */ 
 
				buff = NULL;
                                getline(&buff, &len, fp); 
                                mat.nbsa = atoi(buff);                          /* read(10,*) mat%nbsa          */ 
 
                                alloc1D_I(&(mat.jsa), mat.nbsa);    		/* allocate(mat%jsa(1:mat%nbsa)) */   
                                 
                                for (i = 0; i < mat.nbsa; i++) {                /* do i=1,mat%nbsa */ 
					buff = NULL;
                                        getline(&buff, &len, fp);
					setElem1D_I(&(mat.jsa), i+1, atoi(buff));	/* read(10,*) mat%jsa(i)        */ 
                                }                                               /* end do       */ 
                                fclose(fp);                                     /* close(10)    */

                                sprintf(temp_name, "%s.sa", sname); 
                                fp = fopen(temp_name, "r");                     /* open(10,file=trim(sname)//'.sa',status='old') */ 
 
				buff = NULL;
                                getline(&buff, &len, fp); 
                                mat.nbsa = atoi(buff);                          /* read(10,*) mat%nbsa */ 
 
                                alloc1D_D(&(mat.sa), mat.nbsa);    		/* allocate(mat%sa(1:mat%nbsa)) */ 
 
                                for (i = 0; i < mat.nbsa; i++) {                /* do i=1,mat%nbsa      */ 
                                        buff = NULL;
					getline(&buff, &len, fp); 
					setElem1D_D(&(mat.sa), i+1, atof(buff));	/* read(10,*) mat%sa(i) */
                                }                                               /* end do               */ 
                                fclose(fp);                                     /* close(10)            */ 

                                /* !!! READ the RHS     */ 
                                sprintf(temp_name, "%s.sf", sname);              
                                fp = fopen(temp_name, "r");                     /* open(10,file=trim(sname)//'.sf',status='old')        */ 
 
				buff = NULL;
                                getline(&buff, &len, fp); 
                                sscanf(buff, "%d %d", &(mat.n), &s);            /* read(10,*) mat%n,s   */ 
 
                                alloc2D_D(&f, mat.n, s); 			/* allocate(f(1:mat%n,1:s)) */ 
 
                                for (i= 0; i < mat.n; i++)                      /* do i=1,mat%n         */ 
                                        for (j = 0; j < s; j++) { 
                                                buff = NULL;
						getline(&buff, &len, fp); 
						setElem2D_D(&f, i+1, j+1, atof(buff));	/* read(10,*) f(i,:)     */
                                        }                                       /*  end do */ 
                                fclose(fp);        

             printf("Matrix Loaded\n");
             printf("n:%d\tnnz=%d\n", mat.n,mat.nbsa);

                        } /* end if */   

			MPI_Bcast(&(mat.n),1,MPI_INTEGER,0,MPI_COMM_WORLD);
			MPI_Bcast(&(mat.DIAGDO),1,MPI_CHARACTER,0,MPI_COMM_WORLD);
			MPI_Bcast(&sparse2dbanded,1,MPI_INTEGER,0,MPI_COMM_WORLD);

if (sparse2dbanded==-1) {
             printf("Procedure sparse to dense banded\n");

                        mat.format='D';   
                        mat.ASTRU='G'; 
/* find kl and ku */
if (rank==0) {
mat.kl= -mat.n;
mat.ku=-mat.n;
for (i=1;i<=mat.n;i++) 
for (k=getElem1D_I(&mat.isa,i);k<=getElem1D_I(&mat.isa,i+1)-1;k++) {
tempi=getElem1D_I(&mat.jsa,k);
if (mat.kl<i-tempi) {mat.kl=i-tempi;}
if (mat.ku<-i+tempi) {mat.ku=-i+tempi;}
}

             printf("kl=%d\tku=%d\n", mat.kl,mat.ku);
}

			MPI_Bcast(&(mat.kl),1,MPI_INTEGER,0,MPI_COMM_WORLD);
			MPI_Bcast(&(mat.ku),1,MPI_INTEGER,0,MPI_COMM_WORLD);
/* transform csr to banded */
if (rank==0) {

     alloc2D_D(&(mat.A), mat.kl+mat.ku+1, mat.n); /* allocate(mat%A(1:mat%kl+mat%ku+1,mat%n))     */ 
                temp = 0.0e0; 
                setAll_D(&(mat.A), &temp);
 
for (i=1;i<=mat.n;i++) 
for (k=getElem1D_I(&mat.isa,i);k<=getElem1D_I(&mat.isa,i+1)-1;k++) {
tempi=getElem1D_I(&mat.jsa,k);
setElem2D_D(&(mat.A),i-tempi+mat.ku+1,tempi,getElem1D_D(&mat.sa,k));
}
}
}
else
{

                        mat.format='S'; /* mat%format='S' */  
                        mat.ASTRU='G';  /* mat%ASTRU='G'  */
}
/*
	!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	!!!!!!!!!!!!!!!!!!!! SPIKE ENVIRONMENT !!!!!!!!!
	!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!  
	*/

	spike_begin(&pspike,&mat,&pre, &info);          
        spike_preprocess(&pspike,&pre, &info);
        spike_process(&pspike,&mat,&pre,&f, &info);
        spike_end(&pspike,&mat,&pre, &info);           


	MPI_Finalize();		/* 101 call MPI_FINALIZE(code) */

	return 0;
}

